package hangman;

public class EvilHangman {

    public static void main(String[] args) {

    }

}
